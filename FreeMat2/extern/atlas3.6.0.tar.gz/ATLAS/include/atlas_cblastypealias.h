#ifdef SREAL
   #include "atlas_cblassalias.h"
#elif defined(DREAL)
   #include "atlas_cblasdalias.h"
#elif defined(SCPLX)
   #include "atlas_cblascalias.h"
#elif defined(DCPLX)
   #include "atlas_cblaszalias.h"
#endif
