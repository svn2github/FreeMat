#undef HAVE_ZLIB 
#define HAVE_INTTYPES_H 1
#define HAVE_STRINGS_H 1
#define HAVE_STDINT_H 1
#define STDC_HEADERS 1

#define MATIO_PLATFORM "powerpc-apple-darwin7.9.0"
#define MATIO_MAJOR_VERSION 1
#define MATIO_MINOR_VERSION 1
#define MATIO_RELEASE_LEVEL 4

#undef FC_FUNC
#undef FC_FUNC_

#undef LINUX
#undef WINNT
#undef SUN

#define SIZEOF_DOUBLE 8
#define SIZEOF_FLOAT 4
#define SIZEOF_LONG 4
#define SIZEOF_INT 4
#define SIZEOF_SHORT 2
#define SIZEOF_CHAR 1

#undef HAVE_VA_COPY
#undef HAVE___VA_COPY
#define HAVE_VSNPRINTF 1
#define HAVE_SNPRINTF 1
#define HAVE_VASPRINTF 1
#define HAVE_ASPRINTF 1

